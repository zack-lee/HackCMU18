"use strict";

var SPOTIFY_CLIENT_ID = '31469b011d4941bf8dd4ac9cf8495bac';
var SPOTIFY_REDIRECT_URI = 'http://localhost:8235/SortYourMusic/';
var SPOTIFY_REDIRECT_URI = 'http://localhost:8000/';
var SPOTIFY_REDIRECT_URI = 'http://static.echonest.com/SortYourMusic/';
